pkg=com.pubg.krmobile
GUEST="/data/data/$pkg/shared_prefs/device_id.xml"
am kill $pkg
rm -rf $GUEST
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name=\"random\"></string>
    <string name=\"install\"></string>
    <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > $GUEST
rm -rf /data/data/$pkg/databases
rm -rf /data/media/0/Android/data/$pkg/files/login-identifier.txt
rm -rf /data/media/0/Android/data/$pkg/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /data/media/0/Android/data/$pkg/files/TGPA
iptables -I OUTPUT -d cloud.vmp.onezapp.com -j REJECT
iptables -I INPUT -s cloud.vmp.onezapp.com -j REJECT
chmod 660 /data/data/$pkg/shared_prefs/device_id.xml
