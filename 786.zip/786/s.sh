
set -x
if ping -q -c 1 -W 1 google.com >/dev/null 
then
  echo -e "\nYour Internet is OK"
else
  echo "\nThe network is down"
  sleep 5
  echo "No Internet"
  exit 
fi

#pkg update && clear && pkg upgrade && clear && pkg update && apt update && clear && apt upgrade && clear && pkg install termux-api && pkg install wget && clear && pkg install toilet && clear

if [ -d /data/data/com.termux/files/home/786 ] || [ -f /data/data/com.termux/files/home/786.zip* ] 
then rm -rf /data/data/com.termux/files/home/786*
fi

wget https://download1078.mediafire.com/gyjuutrwhffg/ithoxhjidn02jre/786.zip




ROOT() {
echo "FIRST CHECKING THIS VERSION IS INSTALLED OR NOT"

if su -c [ -d /data/app/$pkg* ] 
then echo "Yes, good to go"
else clear
echo "
UNFORTUNATELY, YOUR DEMANDED PUBG VERSION IS NOT YET INSTALLED"
sleep 10 s 
exit
fi


su -c am kill $pkg && su -c am force-stop $pkg > /dev/null 2>&1
unzip /data/data/com.termux/files/home/786.zip > /dev/null 2>&1

if
su -c [ -d /data/data/$pkg/shared_prefs ]
then echo "Everything is perfect"
else echo "run pubg one time"
sleep 10
exit 
fi


su -c rm -rf /data/data/$pkg/shared_prefs
su -c cp -prf /data/data/com.termux/files/home/786/shared_prefs /data/data/$pkg/
}


toilet TEAM 786 -F border --metal

echo -e '\n                \033[1m\033[4mSELECT  YOUR  PUBG  VERSION\033[0m'

select opt in GLOBAL KOREA VITENAM TIAWAN India Quit 
do
 case $opt in
GLOBAL)
echo -e "   \a\nYOU HAVE SELECTED PUBG $OPT"
 pkg=com.tencent.ig
 ROOT
 su -c ./downloads/gl.sh
;;
KOREA)
echo -e "   \a\nYOU HAVE SELECTED PUBG $OPT"
pkg=com.pubg.krmobile
ROOT

;;
VITENAM)
echo -e "   \a\nYOU HAVE SELECTED PUBG $OPT"
pkg=com.vng.pubgmobile
ROOT

;;
TIAWAN)
echo -e "   \a\nYOU HAVE SELECTED PUBG $OPT"
pkg=com.rekoo.pubgm
ROOT

;;
India)
echo -e "   \a\nYOU HAVE SELECTED PUBG $OPT"
pkg=com.pubg.imobile
ROOT

;;
Quit)
echo THANKS FOR USING THIS SHELL
sleep 1 
termux-toast -g bottom ALLAH HAFIZ
exit
;;
*)
echo YOU ENTERED UNKNOWN OPTION TRY AGAIN 
termux-toast -g bottom -c black  -b red INVALID CHARACTER
;;

esac
done











: ' echo -e "\n
 1) GLOBAL
 2) KOREA
 3) VITENAM 
 4) TIAWAN
 5) India
 6) Quit "

echo

read -p "Please Type Only Number and THAT IS:" A

if [ $A -eq 1 ]
then clear && echo "You Selected 'GLOBAL Version'" && pkg=com.tencent.ig && ROOT && su -c ./downloads/gl.sh
fi
 
(( $a == 2 )) && clear && echo "You Selected 'KOREA Version'" && pkg=com.pubg.krmobile && su -c root

(( $a == 3 )) && clear && echo "You Selected 'VITENAM Version'" && pkg=com.vng.pubgmobile && su -c root

(( $a == 4 )) && clear && echo "You Selected 'TIAWAN Version'" && pkg=com.rekoo.pubgm && su -c root

(( $a == 5 )) && clear && echo "You Selected 'BGMI Version'" && pkg=com.pubg.imobile && root

(( $a == 6 )) && clear && echo "You Selected Quit" && sleep 2 && echo -e "Wait Quitting" && exit

if [[ $a == [7-9a-zA-Z]* ]] 
then
clear && echo "You Selected Unknown Option, Please Run this it again"
fi
 '


#(( $a == 1 )) && clear && echo "You Selected 'GLOBAL Version'" && pkg=com.tencent.ig && ROOT && su -c ./downloads/gl.sh